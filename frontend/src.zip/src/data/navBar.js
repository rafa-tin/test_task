const navBar = [
  {
    id: 1,
    value: "Latest Test",
    link: "latestTest",
  },
  {
    id: 2,
    value: "Results",
    link: "/results",
  },
  {
    id: 3,
    value: "Achievements",
    link: "/achievements",
  },
  {
    id: 4,
    value: "Balance/Tariff",
    link: "/balance",
  },
  {
    id: 5,
    value: "Profile",
    link: "/profile",
  },
];

export default navBar;