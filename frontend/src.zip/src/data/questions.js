 const questions = [
  {
    id: 1,
    question: "What is right option?",
    options: [
      { id: 1, option: "value 1", isRight: false },
      { id: 2, option: "value 2", isRight: true },
      { id: 3, option: "value 3", isRight: false },
      { id: 4, option: "value 4", isRight: false },
    ],
  },
  {
    id: 2,
    question: "Select programming languages",
    options: [
      { id: 1, option: "JavaScript", isRight: false },
      { id: 2, option: "HTML", isRight: false },
      { id: 3, option: "Python", isRight: true },
      { id: 4, option: "CSS", isRight: false },
    ],
  },
];

export default questions