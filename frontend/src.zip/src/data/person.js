const profileData = {
  name: "Rafkat",
  surname: "Gatin",
  age: 20,
  gender: "male",
  country: "Uzbekistan",
  city: "Tashkent",
  number: "+998 90 319 50 12",
  mail: "rafa@mail.com",
  avatar: "avatar.svg",
  password: "123password",
  tariff: "free",
  balance: 10000,
  progress: [
    { id: 1, testName: "For Beginners", correctAnwers: 10, questions: 10 },
    {
      id: 2,
      testName: "For Beginners chapter 2",
      correctAnwers: 10,
      questions: 10,
    },
    { id: 3, testName: "For Beginners pro", correctAnwers: 9, questions: 10 },
    {
      id: 4,
      testName: "Check your knowledge",
      correctAnwers: 6,
      questions: 10,
    },
    { id: 5, testName: "Vocabulary", correctAnwers: 8, questions: 10 },
    { id: 6, testName: "Vocabulary 2", correctAnwers: 6, questions: 10 },
    { id: 7, testName: "Vocabulary 3 ", correctAnwers: 2, questions: 10 },
    { id: 8, testName: "Vocabulary 4", correctAnwers: 8, questions: 10 },
    { id: 9, testName: "Theory", correctAnwers: 3, questions: 10 },
    { id: 10, testName: "For Beginners", correctAnwers: 10, questions: 10 },
    { id: 1, testName: "For Beginners", correctAnwers: 10, questions: 10 },
  ],
};

export default profileData;